clear
clc
%% 初始参数
M = 1.096;    % 小车质量
m = 0.109;    % 摆杆质量
b = 0.1;    % 小车摩擦系数
l = 0.25;    % 摆杆转动轴心到杆质心的长度
I = 0.0034;  % 摆杆惯量
g = 9.8;    % 重力加速度
T = 0.005;  % 采样时间
q = (M+m)*(I+m*l^2)-(m*l)^2;

%% 摆杆角度数学模型
num1 = [m*l/q 0 0];
den1 = [1 b*(I+m*l^2)/q -(M+m)*m*g*l/q -b*m*g*l/q 0];

%% PID数学模型
Kp = 100;
Ki = 1;
Kd = 1;
numPID = [Kd Kp Ki];
denPID = [1 0];

%% 闭环系统传递函数
num = conv(num1,denPID);
den = polyadd(conv(denPID,den1),conv(numPID,num1));

%% 计算并显示传递函数的极点p
[r,p,k] = residue(num,den);
s=p;    % 闭环极点
display(s);

%% 求传递函数的脉冲响应并显示
t = 0:T:5;
impulse(num,den,t);
y = impulse(num,den,t);
% axis([0 5 0 10]);   % 横坐标0-5，纵坐标0-10

%% 输出性能指标
% 稳定时间t_s
flag = 1;
for i=1:1:length(t)
    if abs(y(i))<=1e-3
        if flag==1
            t_s = t(i);
            j = i;
            flag = 0;
        end
    else
        flag = 1;
    end
end
% 稳态后最大夹角变化
fai = max(y(j:end));
% 输出性能指标
fprintf("摆角角度稳定时间为 %.2fs\n",t_s);
fprintf("稳态时，摆角角度最大夹角变化为 %.2frad\n",fai);
