% 求取输入输出匹配系数
function [Nbar] = rscale(A,B,C,D,K)
s = size(A,1);
Z = [zeros([1,s]) 1];
N = inv([A,B;C,D])*Z';
Nx = N(1:s);
Nu = N(1+s);
Nbar = Nu+K*Nx;
end