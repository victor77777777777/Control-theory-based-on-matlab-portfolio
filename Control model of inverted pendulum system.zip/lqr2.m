clear
clc
%% 初始参数
M = 1.096;    % 小车质量
m = 0.109;    % 摆杆质量
b = 0.1;    % 小车摩擦系数
l = 0.25;    % 摆杆转动轴心到杆质心的长度
I = 0.0034;  % 摆杆惯量
g = 9.8;    % 重力加速度
T = 0.005;  % 采样时间
p = (M+m)*I+M*m*l^2;

%% 倒立摆状态方程
A = [0  1   0   0;
    0   -(I+m*l^2)*b/p  (m^2*g*l^2)/p   0;
    0   0   0   1
    0   -(m*l*b)/p  m*g*l*(M+m)/p   0];
B = [0;
    (I+m*l^2)/p
    0;
    m*l/p];
C = [1  0   0   0;
    0   0   1   0];
D = [0;
    0];
p = eig(A);

%% 求向量K
x = 5000;
y = 100;
Q = [x 0 0 0;
    0 0 0 0;
    0 0 y 0;
    0 0 0 0];
R = 1;
K = lqr(A,B,Q,R);

%% 计算LQR控制矩阵
Ac = (A-B*K);
Bc = B;
Cc = C;
Dc = D;

%% 计算增益Nbar
Cn = [1 0 0 0];
Nbar = rscale(A,B,Cn,0,K);
Bcn = Nbar*B;

%% 求阶跃响应并画出曲线
t = 0:T:5;
U = 0.2*ones(size(t));
[Y,X] = lsim(Ac,Bcn,Cc,Dc,U,t);
plot(t,Y(:,1),':',t,Y(:,2),'-');
%axis([0 2 0 100]);   % 横坐标0-2，纵坐标0-100
legend("小车位置","摆杆角度");

%% 性能指标
% x上升时间t_xr
for i=1:1:length(t)
    if Y(i,1)>=Y(length(t),1)*0.9
        t_xr = t(i);
        break;
    end
end
% x稳定时间t_xs
flag = 1;
for i=1:1:length(t)
    if Y(i,1)>=Y(length(t),1)*0.98&&Y(i,1)<=Y(length(t),1)*1.02
        if flag==1
            t_xs = t(i);
            flag = 0;
        end
    else
        flag = 1;
    end
end
% fai稳定时间t_fs
flag = 1;
for i=1:1:length(t)
    if abs(Y(i,2))<=1e-3
        if flag==1
            t_fs = t(i);
            flag = 0;
        end
    else
        flag = 1;
    end
end
% fai超调
mp = max(abs(Y(:,2)));
% 稳态误差
ess = (Y(length(t),1)-0.2)/0.2;
% 输出性能指标
fprintf("摆角角度稳定时间为 %.2fs,小车位移稳定时间为 %.2fs\n",t_fs,t_xs);
fprintf("小车位移上升时间为 %.2fs\n",t_xr);
fprintf("摆角角度超调量为 %.2f度\n",mp*180/pi);
fprintf("小车位移稳态误差为 %.2f%%\n",ess*100);

