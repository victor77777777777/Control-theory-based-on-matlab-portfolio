%% 初始参数
M = 1.096;    % 小车质量
m = 0.109;    % 摆杆质量
b = 0.1;    % 小车摩擦系数
l = 0.25;    % 摆杆转动轴心到杆质心的长度
I = 0.0034;  % 摆杆惯量
g = 9.8;    % 重力加速度
T = 0.005;  % 采样时间
q = (M+m)*(I+m*l^2)-(m*l)^2;

%% 计算并显示多项式形式的传递函数
num = [m*l/q 0 0];
num2 = [-(I+m*l^2)/q 0 m*g*l/q];
den = [1 b*(I+m*l^2)/q -(M+m)*m*g*l/q -b*m*g*l/q 0];
sys = tf(num,den);
sys2 = tf(num2,den);
display(sys);
display(sys2);

%% 计算并显示传递函数的极点p
[r,p,k] = residue(num,den);
s=p;    % 开环极点
display(s);

%% 求传递函数的脉冲响应并显示
t = 0:T:5;
impulse(num,den,t);
axis([0 1 0 60]);   % 横坐标0-1，纵坐标0-60