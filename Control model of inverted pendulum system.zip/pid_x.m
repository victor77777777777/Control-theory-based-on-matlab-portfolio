clear
clc
%% 初始参数
M = 1.096;    % 小车质量
m = 0.109;    % 摆杆质量
b = 0.1;    % 小车摩擦系数
l = 0.25;    % 摆杆转动轴心到杆质心的长度
I = 0.0034;  % 摆杆惯量
g = 9.8;    % 重力加速度
q = (M+m)*(I+m*l^2)-(m*l)^2;

%% 摆杆角度和位置数学模型
num1 = [m*l/q 0 0];
den1 = [1 b*(I+m*l^2)/q -(M+m)*m*g*l/q -b*m*g*l/q 0];
num2 = [-(I+m*l^2)/q 0 m*g*l/q];
den2 = den1;

%% PID数学模型
Kp = 100;
Ki = 1;
Kd = 20;
numPID = [Kd Kp Ki];
denPID = [1 0];

%% 闭环系统传递函数
num = conv(num2,denPID);
den = polyadd(conv(denPID,den2),conv(numPID,num1));

%% 计算并显示传递函数的极点p
[r,p,k] = residue(num,den);
s=p;    % 闭环极点

%% 求传递函数的脉冲响应并显示
t = 0:0.005:5;
impulse(num,den,t);
%axis([0 5 0 10]);   % 横坐标0-5，纵坐标0-10